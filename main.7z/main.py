from os import system
from mascota import Mascota

def main():
    try:
        while True:
            print('***************MENU MASCOTAS********************')

            print('1 -Registrar nueva mascota')
            print('2 -Buscar una mascota')
            print('3 -Actualizar mascota')
            print('4 -Eliminar una mascota')
            print('5 -Salir del sistema')

            print('***************MENU MASCOTAS********************')
            while True:
                try:
                    opcion = int(input('Seleccione una opción: '))
                    break
                except ValueError:
                    print('Opción no válida')

            if opcion == 5:
                print('Gracias por usar nuestra app..')
                break
            
            elif opcion == 1:
                system('cls')
                print('1. Registrar Mascota')
                # Crear un objeto mascota para luego insertar en la bd
                mascota1 = Mascota()
                mascota1.registrar_mascota()
            
            elif opcion == 2:
                system('cls')
                mascota1 = Mascota()
                codigo_mascota = int(input('Código de mascota a buscar: '))
                mascota1.buscar_mascota(codigo_mascota)

            elif opcion == 3:
                system('cls')
                mascota1 = Mascota()
                codigo_mascota = int(input('Código de la mascota a actualizar: '))
                mascota1.actualizar_mascota(codigo_mascota)
            

            elif opcion == 4:
                system('cls')
                print('Menú Eliminar en desarrollo... ')
            else:
                system('cls')
                print('Opción no válida. Intente de nuevo')
    
    except KeyboardInterrupt:
        print('El usuario ha cancelado la ejecución, por favor continue')
    except Exception as error:
        print(f'Ha ocurrido error no codificado {error}')
    finally:
        print('Intente de nuevo')

if __name__ == "__main__":
    main()

